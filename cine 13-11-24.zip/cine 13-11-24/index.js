import express from 'express';
import bodyParser from 'body-parser';
import { servidor } from './config.js'; // Tu configuración de servidor
import routes from './routes.js'; // Importa las rutas
import path from 'path';
import { fileURLToPath } from 'url';
import hbs from 'hbs';

// Crear __dirname para trabajar con módulos ES
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = servidor;

// Configurar el middleware para manejar datos POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configuración de Handlebars
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views')); // Configura tu carpeta de vistas
hbs.registerPartials(path.join(__dirname, 'views/partials')); // Si tienes parciales

// Rutas de la aplicación
app.use('/api', routes); // Asegúrate de que esta línea esté correcta para manejar la ruta "/api/registro"

// Rutas para renderizar las vistas
const botones = [
  { nombre: "Inicio", ruta: "/" },
  { nombre: "Registro", ruta: "/registro" },
  { nombre: "Login", ruta: "/login" },
  { nombre: "Contacto", ruta: "/contacto" },
  { nombre: "Reservar", ruta: "/Reservar" }
  
];

app.get('/', (req, res) => {
  res.status(200).render('index.hbs', { botones });
});

app.get('/login', (req, res) => {
  res.status(200).render('login.hbs', { botones });
});

app.get("/registro", (req, res) => {
  res.status(200).render('registro.hbs', { botones });
});

app.get("/contacto", (req, res) => {
  res.status(200).render('contacto.hbs', { botones });
});

app.get("/Reservar", (req, res) => {
  res.status(200).render('Reservar.hbs', { botones });
});

const port = 3000;
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
