

// Función para verificar la validez de la contraseña
function validarContrasena(contrasena) {
    // Verifica que la contraseña no sea nula o indefinida
    if (!contrasena) {
        return "La contraseña no puede estar vacía.";
    }

    // Expresiones regulares para verificar la complejidad
    const regexMayuscula = /[A-Z]/; // Al menos una mayúscula
    const regexMinuscula = /[a-z]/; // Al menos una minúscula
    const regexNumero = /[0-9]/;    // Al menos un número

    // Verifica la longitud mínima (por ejemplo, 8 caracteres)
    if (contrasena.length < 8) {
        return "La contraseña debe tener al menos 8 caracteres.";
    }

    // Verifica si cumple con las reglas
    if (!regexMayuscula.test(contrasena)) {
        return "La contraseña debe contener al menos una letra mayúscula.";
    }

    if (!regexMinuscula.test(contrasena)) {
        return "La contraseña debe contener al menos una letra minúscula.";
    }

    if (!regexNumero.test(contrasena)) {
        return "La contraseña debe contener al menos un número.";
    }

    // Si pasa todas las pruebas, la contraseña es válida
    return "La contraseña es válida.";
}

// Ejemplo de uso:
const contrasena = "Ejemplo123";
const resultado = validarContrasena(contrasena);
console.log(resultado); // Muestra si la contraseña es válida o no