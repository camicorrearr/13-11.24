import express from 'express';
import { registerUser } from './registerController.js'; // Asegúrate de importar correctamente

const router = express.Router();

// Ruta para registrar usuarios (debe ser "/registro")
router.post('/registro', registerUser);

export default router;
